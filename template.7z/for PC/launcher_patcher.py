# Author: R-YaTian
import sys
import os

FSi_GetFreeUserAreaSize = (
b'\xF8\xB5\x00\xF0\x27\xF8\x04\x1C\xFF\xF7\x64\xFF\x07\x1C\xFF\xF7'
b'\x2F\xFF\x00\x90\xC6\x1B\x11\x20\x00\x05\x25\x1A\xFF\xF7\x28\xFF'
b'\x00\x28\x02\xDA\x00\x20\xC0\x43\xF8\xBD\x00\x2C\x04\xDB\x00\x2F'
b'\x02\xDB\x00\x98\x00\x28\x02\xDA\x00\x20\xC0\x43\xF8\xBD\xAE\x42'
b'\x01\xDA\x30\x1C\xF8\xBD\x11\x20\x00\x05\x84\x42\x00\xDA\x00\x25'
b'\x28\x1C\xF8\xBD'
)

SDNand_GetFreeUserAreaSize = (
b'\xF8\xB5\x00\xF0\x27\xF8\x04\x1C\xFF\xF7\x64\xFF\x07\x1C\xFF\xF7'
b'\x2F\xFF\x00\x90\xC6\x1B\x11\x20\x00\x05\x25\x1A\xFF\xF7\x28\xFF'
b'\x00\x28\x02\xDA\x00\x20\xC0\x43\xF8\xBD\x00\x2C\x04\xDB\x00\x2F'
b'\x09\xDB\x00\x98\x00\x28\x02\xDA\x80\x20\x00\x05\xF8\xBD\xAF\x42'
b'\x01\xDA\x28\x1C\xF8\xBD\x11\x20\x00\x05\x84\x42\x00\xDA\x00\x25'
b'\x28\x1C\xF8\xBD'
)

def replace_bytes_in_file(file_path):
    try:
        with open(file_path, 'rb') as file:
            file_data = file.read()

        print("Searching FSi_GetFreeUserAreaSize...")
        index = file_data.find(FSi_GetFreeUserAreaSize)

        if index == -1:
            print("FSi_GetFreeUserAreaSize not found!")
            return

        # replace
        print("Replace with my SDNand_GetFreeUserAreaSize...")
        updated_data = file_data.replace(FSi_GetFreeUserAreaSize, SDNand_GetFreeUserAreaSize)

        backup_file = file_path + ".bak"
        if os.path.exists(backup_file):
            os.remove(backup_file)
        new_file = file_path

        os.rename(file_path, backup_file)

        with open(new_file, 'wb') as file:
            file.write(updated_data)

        print("Done!")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python launcher_patcher.py <launcher_path>")
        print("Example: python launcher_patcher.py 00000002.app")
    else:
        filePath = sys.argv[1]
        replace_bytes_in_file(filePath)
